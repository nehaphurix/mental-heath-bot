import express from 'express';
import { getPromptResponse, getChatbotResponse } from './conversationManager.js';
import Mood from './moodModel.js';

const router = express.Router();

router.get('/', (req, res) => {
  res.send('Mental Health Bot API is running.');
});

// ✅ updated POST /message route
router.post('/message', async (req, res) => {
  const { message } = req.body;

  try {
    const aiResponse = await getChatbotResponse(message);  // <-- AI-generated response
    res.json({ response: aiResponse });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to get response from AI.' });
  }
});

router.post('/mood', async (req, res) => {
  const { userId, mood, note } = req.body;
  try {
    const moodEntry = new Mood({ userId, mood, note });
    await moodEntry.save();
    res.status(201).json({ message: 'Mood logged successfully.' });
  } catch (err) {
    res.status(500).json({ error: 'Error logging mood.' });
  }
});

router.get('/mood/:userId', async (req, res) => {
  try {
    const moods = await Mood.find({ userId: req.params.userId }).sort({ createdAt: -1 });
    res.json(moods);
  } catch (err) {
    res.status(500).json({ error: 'Error fetching moods.' });
  }
});

export default router;